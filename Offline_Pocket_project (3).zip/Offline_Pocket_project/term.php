<!DOCTYPE html>
<html>

<head>

       <link href="termStyle.css" rel="stylesheet" type="text/css" />

</head>




<body>

<section class="product_info">

  <section class="product-details_container">

   <div class="product-details_banner-container">
   <img src="bankIslam.jpg" class="product-details__banner">
   
   </div>
   
   <div class="product-details_description">
     <h2 class="product-details_name"> Mobile Legends Bang Bang </h2>
   
    <div class="product-details_content">
      <p class="shop-content--paragraph"> Our company has partner with moonton to offer easy, safe and convenient Mobile Legends top up</p>
      
	  <p class="shop-content--paragraph"> Buy Mobile Legends Diamonds, Twilight Pass and Weekly Pass in seconds! Just enter your Mobile Legends user ID and zone ID, select the item you wish to purchase, complete the payment, and the item will be instantly delivered to your Mobile Legends account.</p>

      <p class="shop-content--paragraph"> Pay conveniently with Codacash, MAE, Touch ’n Go eWallet, ShopeePay, GrabPay, Boost, FPX, Celcom, U Mobile, Digi, Maxis, and Card Payments.</p>

     </div>
    </div>
  
  </section>
</section>




</body>













</html>