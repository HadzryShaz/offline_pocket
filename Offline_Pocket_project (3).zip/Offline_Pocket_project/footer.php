
<html>

<head>

<style>
.footer{
background:#000;
padding:10px 0px;
font-family: 'Play', sans-serif;
text-align:center;
height:100px;
bottom:0;
}

.footer .row{
width:100%;
margin:1% 0%;
padding:0.6% 0%;
color:gray;
font-size:0.8em;
}

.footer .row a{
text-decoration:none;
color:gray;
transition:0.5s;
}

.footer .row a:hover{
color:#fff;
}

.footer .row ul{
width:100%;
}

.footer .row ul li{
display:inline-block;
margin:0px 30px;
}

.footer .row a i{
font-size:2em;
margin:0% 1%;
}

@media (max-width:720px){
.footer{
text-align:left;
padding:5%;
}
.footer .row ul li{
display:block;
margin:10px 0px;
text-align:left;
}
.footer .row a i{
margin:0% 3%;
}
}


</style>
</head>


<body>
<!--FONT AWESOME-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--GOOGLE FONTS-->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 
</head>
<body>
<footer style="height:150px; ">
<div class="footer">
<div class="row">
<a href="facebook.com"><i class="fa fa-facebook"></i></a>
<a href="instagram.com"><i class="fa fa-instagram"></i></a>
<a href="youtube.com"><i class="fa fa-youtube"></i></a>
<a href="twitter.com"><i class="fa fa-twitter"></i></a>
</div>

<div class="row">
<ul>
<li><a href="https://wa.link/1y3a3v">Contact us</a></li>
<li><a href="#">Our Services</a></li>
<li><a >Privacy Policy</a></li>
<li><a >Terms & Conditions</a></li>
<li><a >Career</a></li>
</ul>
</div>

<div class="row" style="background-color:black;">
Offline Pocket Copyright © 2003 Inferno - All rights reserved || Designed By: Offline Pocket Team
</div>
</div>
</footer>


		
		</body>
		
		</html>